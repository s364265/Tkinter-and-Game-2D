import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import numpy as np
import onnxruntime as ort

# Base class for handling the AI model (Encapsulation)
class ModelHandler:
    def __init__(self):
        self.model_path = 'mobilenetv2.onnx'
        self.session = ort.InferenceSession(self.model_path)
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name

    def preprocess(self, image):
        image = image.resize((224, 224))
        image = np.array(image).astype('float32')
        image = np.expand_dims(image, axis=0)
        image = np.transpose(image, (0, 3, 1, 2))
        image = image / 255.0
        return image

    def predict(self, image):
        image = self.preprocess(image)
        outputs = self.session.run([self.output_name], {self.input_name: image})
        return np.argmax(outputs)

# Decorator for logging actions (Multiple Decorators)
def logger(func):
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__}")
        return func(*args, **kwargs)
    return wrapper

# Another decorator for error handling
def error_handler(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"Error in {func.__name__}: {e}")
    return wrapper

# Multiple Inheritance (Tkinter Frame and ModelHandler)
class App(tk.Tk, ModelHandler):
    def __init__(self):
        tk.Tk.__init__(self)  # Initialize Tkinter
        ModelHandler.__init__(self)  # Initialize ModelHandler
        self.title("Image Classification App")
        self.geometry("500x500")
        self.create_widgets()

    # Polymorphism: create_widgets method can be overridden by subclasses
    def create_widgets(self):
        self.label = tk.Label(self, text="Choose an image to classify")
        self.label.pack()

        self.btn_load = tk.Button(self, text="Load Image", command=self.load_image)
        self.btn_load.pack()

        self.image_label = tk.Label(self)
        self.image_label.pack()

        self.result_label = tk.Label(self, text="")
        self.result_label.pack()

    # Method Overriding: Overriding the logger decorator for load_image method
    @logger
    @error_handler
    def load_image(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            image = Image.open(file_path)
            self.display_image(image)
            result = self.predict(image)
            self.display_result(result)

    def display_image(self, image):
        img_tk = ImageTk.PhotoImage(image)
        self.image_label.config(image=img_tk)
        self.image_label.image = img_tk

    def display_result(self, result):
        self.result_label.config(text=f"Predicted Class: {result}")

if __name__ == "__main__":
    app = App()
    app.mainloop()
