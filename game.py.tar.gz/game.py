import pygame
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Side-Scrolling Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Clock
clock = pygame.time.Clock()
FPS = 60

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect(center=(100, SCREEN_HEIGHT//2))
        self.speed = 7
        self.health = 100
        self.lives = 3
        self.score = 0
        self.jump_speed = -15
        self.gravity = 1
        self.is_jumping = False
        self.velocity_y = 0

    def move_up(self):
        self.rect.y -= self.speed

    def move_down(self):
        self.rect.y += self.speed

    def move_forward(self):
        self.rect.x += self.speed

    def move_backward(self):
        self.rect.x -= self.speed

    def jump(self):
        if not self.is_jumping:
            self.is_jumping = True
            self.velocity_y = self.jump_speed

    def shoot(self):
        projectile = Projectile(self.rect.centerx, self.rect.centery)
        all_sprites.add(projectile)
        projectiles.add(projectile)

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            self.move_up()
        if keys[pygame.K_DOWN]:
            self.move_down()
        if keys[pygame.K_RIGHT]:
            self.move_forward()
        if keys[pygame.K_LEFT]:
            self.move_backward()
        if keys[pygame.K_1]:
            self.jump()
        if keys[pygame.K_SPACE]:
            self.shoot()

        # Apply gravity
        if self.is_jumping:
            self.rect.y += self.velocity_y
            self.velocity_y += self.gravity
            if self.rect.bottom >= SCREEN_HEIGHT:
                self.rect.bottom = SCREEN_HEIGHT
                self.is_jumping = False

    def take_damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            self.lose_life()

    def gain_health(self, amount):
        self.health = min(100, self.health + amount)

    def lose_life(self):
        self.lives -= 1
        if self.lives <= 0:
            game_over()

    def add_score(self, points):
        self.score += points

# Projectile class
class Projectile(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((10, 5))
        self.image.fill(RED)
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 10

    def update(self):
        self.rect.x += self.speed
        if self.rect.x > SCREEN_WIDTH:
            self.kill()

    def check_collision(self, target):
        if pygame.sprite.collide_rect(self, target):
            target.take_damage(10)
            self.kill()

# Enemy class
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(RED)
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 2
        self.health = 50

    def update(self):
        if self.rect.x > player.rect.x:
            self.rect.x -= self.speed
        else:
            self.rect.x += self.speed

        if self.rect.y > player.rect.y:
            self.rect.y -= self.speed
        else:
            self.rect.y += self.speed

    def take_damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            self.kill()
            player.add_score(10)

# Collectible class
class Collectible(pygame.sprite.Sprite):
    def __init__(self, x, y, type):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        if type == "health":
            self.image.fill(GREEN)
        elif type == "life":
            self.image.fill(BLUE)
        self.rect = self.image.get_rect(center=(x, y))
        self.type = type
        self.speed = 5

    def update(self):
        self.rect.x -= self.speed
        if self.rect.x < 0:
            self.kill()

    def apply_effect(self, player):
        if self.type == "health":
            player.gain_health(20)
        elif self.type == "life":
            player.lives += 1
        self.kill()

# Level design
class Level:
    def __init__(self, level_number):
        self.level_number = level_number
        self.enemies = pygame.sprite.Group()
        self.collectibles = pygame.sprite.Group()
        self.load_level()

    def load_level(self):
        num_enemies = 10 * self.level_number
        for _ in range(num_enemies):
            enemy = Enemy(random.randint(SCREEN_WIDTH, SCREEN_WIDTH + 1000), random.randint(50, SCREEN_HEIGHT - 50))
            all_sprites.add(enemy)
            self.enemies.add(enemy)

        for _ in range(3):
            collectible = Collectible(random.randint(SCREEN_WIDTH, SCREEN_WIDTH + 1000), random.randint(50, SCREEN_HEIGHT - 50), random.choice(["health", "life"]))
            all_sprites.add(collectible)
            self.collectibles.add(collectible)

    def check_completion(self):
        if not self.enemies:
            self.level_number += 1
            self.load_level()

# Game mechanics
def game_over():
    global running
    running = False

# Sprite groups
all_sprites = pygame.sprite.Group()
projectiles = pygame.sprite.Group()
levels = [Level(1)]
current_level = levels[0]

player = Player()
all_sprites.add(player)

# Timer for collectibles
ADD_COLLECTIBLE = pygame.USEREVENT + 1
pygame.time.set_timer(ADD_COLLECTIBLE, 20000)

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == ADD_COLLECTIBLE:
            collectible = Collectible(random.randint(SCREEN_WIDTH, SCREEN_WIDTH + 1000), random.randint(50, SCREEN_HEIGHT - 50), random.choice(["health", "life"]))
            all_sprites.add(collectible)
            current_level.collectibles.add(collectible)

    # Update
    all_sprites.update()
    for projectile in projectiles:
        for enemy in current_level.enemies:
            projectile.check_collision(enemy)

    for collectible in current_level.collectibles:
        if pygame.sprite.collide_rect(player, collectible):
            collectible.apply_effect(player)

    current_level.check_completion()

    # Draw
    screen.fill(BLACK)
    all_sprites.draw(screen)

    # Health bar
    pygame.draw.rect(screen, RED, (10, 10, player.health, 20))
    
    # Score bar
    font = pygame.font.SysFont(None, 25)
    score_text = font.render(f"Score: {player.score}", True, WHITE)
    screen.blit(score_text, (10, 40))
    
    # Lives
    lives_text = font.render(f"Lives: {player.lives}", True, WHITE)
    screen.blit(lives_text, (10, 70))

    # Game over screen
    if player.lives <= 0:
        font = pygame.font.SysFont(None, 55)
        text = font.render("Game Over. Press R to Restart", True, WHITE)
        screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//2 - text.get_height()//2))
        keys = pygame.key.get_pressed()
        if keys[pygame.K_r]:
            player.lives = 3
            player.health = 100
            player.score = 0
            current_level = Level(1)
            levels[0] = current_level
            all_sprites.add(player)
            running = True

    # Flip the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(FPS)

pygame.quit()
